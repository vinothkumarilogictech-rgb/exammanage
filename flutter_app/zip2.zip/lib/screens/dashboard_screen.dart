import 'package:flutter/material.dart';

import '../app_theme.dart';
import '../models.dart';
import '../services/dio_client.dart';
import '../widgets/common.dart';
import '../providers/branch_context.dart';
import '../providers/auth_provider.dart';
import 'package:provider/provider.dart';
import 'attended_candidates_screen.dart';
import 'scheduled_candidates_screen.dart';
import 'expenses_screen.dart';
import 'vouchers_screen.dart';
import 'available_vouchers_screen.dart';
import 'profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  final api = DioClient();

  late Future<Map<String, dynamic>> future;
  late final BranchContext _branchContext;

  // Voucher sales that are still Pending / Partial (balance_amount > 0),
  // shown via the notification bell in the app bar.
  List<Map<String, dynamic>> _pendingSales = [];
  // Voucher-purchase invoices that are still Pending / Partial, shown in
  // the same notification bell alongside pending voucher sales.
  List<Map<String, dynamic>> _pendingInvoices = [];

  int get _pendingCount => _pendingSales.length + _pendingInvoices.length;

  @override
  void initState() {
    super.initState();
    _branchContext = context.read<BranchContext>();
    _branchContext.addListener(_onBranchChanged);
    future = load();
    _loadPendingSales();
  }

  void _onBranchChanged() {
    if (!mounted) return;
    setState(() {
      future = load();
    });
    _loadPendingSales();
  }

  // ================================================================
  // PENDING / PARTIAL PAYMENTS — voucher sales + purchase invoices
  // (notification bell)
  // ================================================================

  Future<void> _loadPendingSales() async {
    try {
      await _branchContext.ensureLoaded();
      final branchId = _branchContext.selectedBranchId;
      final results = await Future.wait([
        api.voucherHistory(branchId: branchId),
        api.invoices(branchId: branchId),
      ]);

      final saleRows = (results[0].data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .where((h) {
            final status = '${h['payment_status'] ?? ''}';
            final balance = double.tryParse('${h['balance_amount'] ?? 0}') ?? 0;
            return balance > 0 || status == 'Pending' || status == 'Partial';
          })
          .toList();
      saleRows.sort((a, b) => '${b['sold_at'] ?? ''}'.compareTo('${a['sold_at'] ?? ''}'));

      final invoiceRows = (results[1].data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .where((inv) {
            final invStatus = '${inv['status'] ?? ''}';
            final status = '${inv['payment_status'] ?? ''}';
            final balance = double.tryParse('${inv['balance_amount'] ?? 0}') ?? 0;
            return invStatus == 'Active' && (balance > 0 || status == 'Pending' || status == 'Partial');
          })
          .toList();
      invoiceRows.sort((a, b) => '${b['invoice_date'] ?? ''}'.compareTo('${a['invoice_date'] ?? ''}'));

      if (mounted) setState(() {
        _pendingSales = saleRows;
        _pendingInvoices = invoiceRows;
      });
    } catch (_) {
      // Silently ignore — the bell just stays at its last known count.
    }
  }

  String _fullMoney(dynamic value) {
    final n = double.tryParse('${value ?? 0}') ?? 0;
    return '₹${n.toStringAsFixed(2)}';
  }

  String _saleDateTime(dynamic value) {
    if (value == null || '$value'.isEmpty) return '-';
    final d = DateTime.tryParse('$value')?.toLocal();
    if (d == null) return '$value';
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';
  }

  List<Map<String, dynamic>> _combinedPendingItems() {
    final combined = <Map<String, dynamic>>[
      for (final s in _pendingSales)
        {
          '_kind': 'sale',
          '_data': s,
          '_date': '${s['sold_at'] ?? ''}',
          'title': '${s['student_name'] ?? '-'}',
          'subtitle': '${s['voucher_code'] ?? '-'}',
          'status': '${s['payment_status'] ?? ''}',
          'balance': s['balance_amount'],
        },
      for (final inv in _pendingInvoices)
        {
          '_kind': 'invoice',
          '_data': inv,
          '_date': '${inv['invoice_date'] ?? ''}',
          'title': '${inv['supplier'] ?? '-'}',
          'subtitle': 'Invoice ${inv['invoice_number'] ?? '-'}',
          'status': '${inv['payment_status'] ?? ''}',
          'balance': inv['balance_amount'],
        },
    ];
    combined.sort((a, b) => '${b['_date']}'.compareTo('${a['_date']}'));
    return combined;
  }

  void _showPendingPaymentsSheet() {
    final items = _combinedPendingItems();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .85),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(4)))),
            const SizedBox(height: 14),
            Row(children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(color: const Color(0xFF9A22C7).withOpacity(.10), borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.notifications_rounded, color: Color(0xFF9A22C7)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Pending & Partial Payments', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text('${items.length} item${items.length == 1 ? '' : 's'} with amount due (sales + invoices)',
                      style: TextStyle(fontSize: 12.5, color: Colors.grey.shade600)),
                ]),
              ),
            ]),
            const SizedBox(height: 16),
            Flexible(
              child: items.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      child: Center(
                        child: Column(children: [
                          Icon(Icons.check_circle_outline_rounded, size: 48, color: Colors.grey.shade300),
                          const SizedBox(height: 10),
                          Text('No pending or partial payments', style: TextStyle(color: Colors.grey.shade500)),
                        ]),
                      ),
                    )
                  : ListView.separated(
                      shrinkWrap: true,
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (_, i) {
                        final item = items[i];
                        final kind = item['_kind'];
                        final status = '${item['status'] ?? ''}';
                        final isPending = status == 'Pending';
                        final color = isPending ? AppColors.red : AppColors.orange;
                        return InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () {
                            Navigator.pop(ctx);
                            if (kind == 'invoice') {
                              _showInvoiceDetailsSheet(Map<String, dynamic>.from(item['_data']));
                            } else {
                              _showSaleDetailsSheet(Map<String, dynamic>.from(item['_data']));
                            }
                          },
                          child: Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF7F5FD),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: color.withOpacity(.25)),
                            ),
                            child: Row(children: [
                              Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
                                child: Icon(
                                  kind == 'invoice'
                                      ? Icons.receipt_long_rounded
                                      : (isPending ? Icons.error_outline_rounded : Icons.hourglass_bottom_rounded),
                                  color: color,
                                  size: 20,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text('${item['title']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                                  const SizedBox(height: 2),
                                  Text('${item['subtitle']}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                                ]),
                              ),
                              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(20)),
                                  child: Text(status, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: color)),
                                ),
                                const SizedBox(height: 4),
                                Text(_fullMoney(item['balance']), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: color)),
                              ]),
                              const Icon(Icons.chevron_right_rounded, color: Colors.grey),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSaleDetailsSheet(Map<String, dynamic> s) {
    final status = '${s['payment_status'] ?? ''}';
    final color = status == 'Pending' ? AppColors.red : (status == 'Partial' ? AppColors.orange : AppColors.green);

    Widget row(String label, String value) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 128, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
            Expanded(child: Text(value.isEmpty ? '-' : value, style: const TextStyle(fontWeight: FontWeight.w700))),
          ]),
        );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .88),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(4)))),
              const SizedBox(height: 14),
              Row(children: [
                Container(width: 46, height: 46, decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.receipt_long_rounded, color: color)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${s['student_name'] ?? '-'}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text('${s['voucher_code'] ?? '-'}', style: TextStyle(fontSize: 12.5, color: Colors.grey.shade600)),
                ])),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(20)),
                  child: Text(status, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: color)),
                ),
              ]),
              const Divider(height: 28),
              row('Mobile', '${s['mobile'] ?? ''}'),
              row('Email', '${s['email'] ?? ''}'),
              row('Address', '${s['address'] ?? ''}'),
              row('ID Number', '${s['id_number'] ?? ''}'),
              const Divider(height: 28),
              row('Selling Price', _fullMoney(s['selling_price'])),
              row('Discount', _fullMoney(s['discount'])),
              row('Final Amount', _fullMoney(s['final_amount'])),
              row('Paid Amount', _fullMoney(s['paid_amount'])),
              row('Pending Amount', _fullMoney(s['balance_amount'])),
              row('Payment Mode', '${s['payment_mode'] ?? ''}'),
              row('Payment Reference', '${s['payment_reference'] ?? ''}'),
              row('Sold At', _saleDateTime(s['sold_at'])),
              row('Notes', '${s['notes'] ?? ''}'),
            ],
          ),
        ),
      ),
    );
  }

  void _showInvoiceDetailsSheet(Map<String, dynamic> inv) {
    final status = '${inv['payment_status'] ?? ''}';
    final color = status == 'Pending' ? AppColors.red : (status == 'Partial' ? AppColors.orange : AppColors.green);
    final items = (inv['items'] as List? ?? []).map((e) => Map<String, dynamic>.from(e)).toList();

    Widget row(String label, String value) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 128, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
            Expanded(child: Text(value.isEmpty ? '-' : value, style: const TextStyle(fontWeight: FontWeight.w700))),
          ]),
        );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .88),
        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(4)))),
              const SizedBox(height: 14),
              Row(children: [
                Container(width: 46, height: 46, decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.receipt_long_rounded, color: color)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${inv['invoice_number'] ?? '-'}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text('${inv['supplier'] ?? '-'}', style: TextStyle(fontSize: 12.5, color: Colors.grey.shade600)),
                ])),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(20)),
                  child: Text(status, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: color)),
                ),
              ]),
              const Divider(height: 28),
              row('Branch', '${inv['branch_name'] ?? ''}'),
              row('Invoice Date', _saleDateTime(inv['invoice_date'])),
              const SizedBox(height: 8),
              const Text('Items', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              ...items.map((x) => Container(
                    margin: const EdgeInsets.only(bottom: 7),
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(12)),
                    child: Row(children: [
                      Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${x['exam_name'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800)),
                        Text('${x['quantity'] ?? 0} × ${_fullMoney(x['unit_price'])}', style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                      ])),
                      Text(_fullMoney(x['total_amount']), style: const TextStyle(fontWeight: FontWeight.w900)),
                    ]),
                  )),
              const Divider(height: 24),
              row('Subtotal', _fullMoney(inv['subtotal'])),
              row('Grand Total', _fullMoney(inv['total_amount'])),
              row('Paid Amount', _fullMoney(inv['paid_amount'])),
              row('Pending Amount', _fullMoney(inv['balance_amount'])),
              row('Payment Mode', '${inv['payment_mode'] ?? ''}'),
              row('Payment Reference', '${inv['payment_reference'] ?? ''}'),
              row('Notes', '${inv['notes'] ?? ''}'),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _branchContext.removeListener(_onBranchChanged);
    super.dispose();
  }

  Future<Map<String, dynamic>> load() async {
    final isAdmin =
        context.read<AuthProvider>().role.trim().toLowerCase() == 'admin';
    await _branchContext.ensureLoaded();
    final branchId = _branchContext.selectedBranchId;

    Map<String, dynamic> data = {};
    DashboardStats stats = DashboardStats.fromMap(const {});
    try {
      final r = await api.dashboard(branchId: branchId);
      data = Map<String, dynamic>.from(r.data['data'] ?? {});
      stats = DashboardStats.fromMap(
        Map<String, dynamic>.from(data['stats'] ?? {}),
      );
    } catch (_) {
      // The dashboard summary may be unavailable for this account/branch
      // (e.g. a permission restriction). Keep the rest of the screen
      // usable with empty defaults instead of showing a crash screen.
    }

    List<Candidate> allCandidates = [];
    try {
      final candRes = await api.candidates(branchId: branchId);
      allCandidates = (candRes.data['data'] as List? ?? [])
          .map((e) => Candidate.fromMap(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {}

    bool isSameDate(String? candDate, String? targetDate) {
      if (candDate == null || targetDate == null) return false;
      final c = candDate.trim();
      final t = targetDate.trim();
      if (c.isEmpty || t.isEmpty) return false;
      if (c == t) return true;
      if (c.startsWith(t) || t.startsWith(c)) return true;
      final cDt = DateTime.tryParse(c);
      final tDt = DateTime.tryParse(t);
      if (cDt != null && tDt != null) {
        return cDt.year == tDt.year &&
            cDt.month == tDt.month &&
            cDt.day == tDt.day;
      }
      return false;
    }

    final todayCandidatesList = allCandidates
        .where(
          (c) => isSameDate(c.date, stats.today) && c.status != 'Cancelled',
        )
        .toList();
    final tomorrowCandidatesList = allCandidates
        .where(
          (c) => isSameDate(c.date, stats.tomorrow) && c.status != 'Cancelled',
        )
        .toList();

    // ==============================================================
    // CURRENT MONTH CANDIDATE SUMMARY
    // ==============================================================
    // Dashboard candidate totals are intentionally month-wise.  The
    // current calendar month is calculated from the device date, so
    // when a new month starts these three counts automatically switch
    // to the new month's candidates without deleting old records.
    final now = DateTime.now();
    bool isCurrentMonth(String? value) {
      if (value == null || value.trim().isEmpty) return false;
      final d = DateTime.tryParse(value.trim());
      return d != null && d.year == now.year && d.month == now.month;
    }

    final currentMonthCandidates = allCandidates
        .where((c) => isCurrentMonth(c.date) && c.status != 'Cancelled')
        .toList();

    final currentMonthTotal = currentMonthCandidates.length;
    final currentMonthAbsent = currentMonthCandidates
        .where((c) => (c.status ?? '').trim().toLowerCase() == 'absent')
        .length;
    final currentMonthRescheduled = currentMonthCandidates
        .where((c) => (c.status ?? '').trim().toLowerCase() == 'rescheduled')
        .length;
    final currentMonthCompleted = currentMonthCandidates
        .where((c) => (c.status ?? '').trim().toLowerCase() == 'completed')
        .length;

    // Financial/voucher summaries are admin-only. Do not request these
    // datasets for employee/user sessions.
    double currentMonthExpense = 0;
    double previousMonthExpense = 0;
    Map<String, dynamic> voucherStats = {};
    if (isAdmin) {
      try {
        final voucherRes = await api.voucherDashboard(branchId: branchId);
        voucherStats = Map<String, dynamic>.from(voucherRes.data['data'] ?? {});
      } catch (_) {}

      try {
        final prevMonthDate = DateTime(now.year, now.month - 1, 1);
        final expenseRes = await api.expenses(
          branchId: branchId,
          status: 'Active',
        );
        final expenses = expenseRes.data['data'] as List? ?? const [];
        for (final raw in expenses) {
          final e = Map<String, dynamic>.from(raw);
          final amount = double.tryParse('${e['amount'] ?? 0}') ?? 0;
          final dateRaw = '${e['date_incurred'] ?? ''}';
          final d = DateTime.tryParse(dateRaw);
          if (d != null && d.year == now.year && d.month == now.month) {
            currentMonthExpense += amount;
          } else if (d != null &&
              d.year == prevMonthDate.year &&
              d.month == prevMonthDate.month) {
            previousMonthExpense += amount;
          }
        }
      } catch (_) {}
    }

    return {
      'stats': stats,

      'branches': (data['branch_overview'] as List? ?? [])
          .map((e) => DashboardBranch.fromMap(Map<String, dynamic>.from(e)))
          .toList(),

      'todayExams': (data['today_exams'] as List? ?? [])
          .map((e) => DashboardExam.fromMap(Map<String, dynamic>.from(e)))
          .toList(),

      'tomorrow': (data['tomorrow_candidates'] as List? ?? [])
          .map(
            (e) =>
                TomorrowBranchCandidates.fromMap(Map<String, dynamic>.from(e)),
          )
          .toList(),

      'todayCandidates': todayCandidatesList,
      'tomorrowCandidates': tomorrowCandidatesList,
      'allCandidates': allCandidates,
      'currentMonthTotal': currentMonthTotal,
      'currentMonthAbsent': currentMonthAbsent,
      'currentMonthRescheduled': currentMonthRescheduled,
      'currentMonthCompleted': currentMonthCompleted,
      'currentMonthExpense': currentMonthExpense,
      'previousMonthExpense': previousMonthExpense,
      'voucherStats': voucherStats,
      'selectedBranchId': branchId,
    };
  }

  void reload() {
    setState(() {
      future = load();
    });
    _loadPendingSales();
  }

  String prettyDate(String value) {
    final d = DateTime.tryParse(value);

    if (d == null) {
      return value;
    }

    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    return '${d.day} ${months[d.month - 1]} ${d.year}';
  }

  // ===========================================================
  // ADD NEW EXAM (Session) DIALOG
  // ===========================================================

  Future<void> _showAddExamDialog() async {
    // Load branches and exam types separately
    List<Map<String, dynamic>> branchesList = [];
    List<Map<String, dynamic>> examTypesList = [];
    try {
      final br = await api.branches();
      branchesList = (br.data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      final et = await api.examTypes();
      examTypesList = (et.data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (_) {}

    if (branchesList.isEmpty || examTypesList.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Please create branches and exam types first.'),
          ),
        );
      }
      return;
    }

    int? selectedBranchId = branchesList.first['id'];
    int? selectedExamTypeId = examTypesList.first['id'];
    final dateCtrl = TextEditingController();
    final startCtrl = TextEditingController(text: '09:00');
    final endCtrl = TextEditingController(text: '12:00');
    final feeCtrl = TextEditingController(text: '0');
    final capacityCtrl = TextEditingController(text: '10');

    if (!mounted) return;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          return Container(
            decoration: const BoxDecoration(
              color: AppColors.surfaceAlt,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            padding: EdgeInsets.fromLTRB(
              24,
              16,
              24,
              MediaQuery.of(ctx).viewInsets.bottom + 24,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF9A22C7), Color(0xFF9A3412)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.note_add_rounded,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'Add New Exam Session',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Branch dropdown
                  _FieldLabel('Branch'),
                  const SizedBox(height: 6),
                  _buildDropdown<int>(
                    value: selectedBranchId,
                    hint: 'Select branch',
                    items: branchesList
                        .map(
                          (b) => DropdownMenuItem<int>(
                            value: b['id'],
                            child: Text(
                              '${b['branch_name'] ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (val) =>
                        setSheetState(() => selectedBranchId = val),
                  ),

                  const SizedBox(height: 14),

                  // Exam Type dropdown
                  _FieldLabel('Exam Type'),
                  const SizedBox(height: 6),
                  _buildDropdown<int>(
                    value: selectedExamTypeId,
                    hint: 'Select exam type',
                    items: examTypesList
                        .map(
                          (e) => DropdownMenuItem<int>(
                            value: e['id'],
                            child: Text(
                              '${e['name'] ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (val) =>
                        setSheetState(() => selectedExamTypeId = val),
                  ),

                  const SizedBox(height: 14),

                  // Date
                  _FieldLabel('Exam Date'),
                  const SizedBox(height: 6),
                  _buildDateField(ctx, dateCtrl),

                  const SizedBox(height: 14),

                  // Time row
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _FieldLabel('Start Time'),
                            const SizedBox(height: 6),
                            _buildTextField(startCtrl, 'HH:MM'),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _FieldLabel('End Time'),
                            const SizedBox(height: 6),
                            _buildTextField(endCtrl, 'HH:MM'),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Fee + Capacity
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _FieldLabel('Fee'),
                            const SizedBox(height: 6),
                            _buildTextField(
                              feeCtrl,
                              '0.00',
                              keyboardType: TextInputType.number,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _FieldLabel('Seat Capacity'),
                            const SizedBox(height: 6),
                            _buildTextField(
                              capacityCtrl,
                              '0',
                              keyboardType: TextInputType.number,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: Color(0xFF6C1FB0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      onPressed: () async {
                        if (dateCtrl.text.isEmpty ||
                            selectedBranchId == null ||
                            selectedExamTypeId == null) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            const SnackBar(
                              content: Text('Please fill all required fields'),
                            ),
                          );
                          return;
                        }
                        try {
                          // Auto-create branch-exam mapping if needed
                          int? mappingId;
                          try {
                            final mapResp = await api.createBranchMapping({
                              'branch_id': selectedBranchId,
                              'exam_type_id': selectedExamTypeId,
                            });
                            mappingId = mapResp.data['data']?['id'];
                          } catch (e) {
                            // Mapping may already exist (409), find existing
                            final existing = await api.branchMappings(
                              branchId: selectedBranchId,
                            );
                            final list = existing.data['data'] as List? ?? [];
                            for (final m in list) {
                              if (m['exam_type_id'] == selectedExamTypeId) {
                                mappingId = m['id'];
                                break;
                              }
                            }
                          }
                          if (mappingId == null) {
                            if (ctx.mounted) {
                              ScaffoldMessenger.of(ctx).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    'Could not create branch-exam mapping',
                                  ),
                                ),
                              );
                            }
                            return;
                          }
                          await api.createSession({
                            'branch_exam_id': mappingId,
                            'exam_date': dateCtrl.text,
                            'start_time': startCtrl.text,
                            'end_time': endCtrl.text,
                            'fee': double.tryParse(feeCtrl.text) ?? 0,
                            'seat_capacity':
                                int.tryParse(capacityCtrl.text) ?? 0,
                          });
                          if (ctx.mounted) {
                            Navigator.pop(ctx);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Exam session created!'),
                                backgroundColor: AppColors.green,
                              ),
                            );
                            reload();
                          }
                        } catch (e) {
                          if (ctx.mounted) {
                            ScaffoldMessenger.of(ctx).showSnackBar(
                              SnackBar(content: Text('Error: $e')),
                            );
                          }
                        }
                      },
                      child: const Text(
                        'Create Exam Session',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // Helper widgets for bottom sheet fields
  Widget _buildDropdown<T>({
    required T? value,
    required String hint,
    required List<DropdownMenuItem<T>> items,
    required ValueChanged<T?> onChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          isExpanded: true,
          value: value,
          hint: Text(hint),
          items: items,
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController ctrl,
    String hint, {
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
      ),
    );
  }

  Widget _buildDateField(
    BuildContext ctx,
    TextEditingController ctrl, {
    bool allowPast = false,
  }) {
    return TextField(
      controller: ctrl,
      readOnly: true,
      decoration: InputDecoration(
        hintText: 'Select date',
        suffixIcon: const Icon(Icons.calendar_today_rounded),
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
      ),
      onTap: () async {
        final picked = await showDatePicker(
          context: ctx,
          initialDate: DateTime.now(),
          firstDate: allowPast
              ? DateTime.now().subtract(const Duration(days: 30))
              : DateTime.now(),
          lastDate: DateTime.now().add(const Duration(days: 365)),
        );
        if (picked != null) {
          ctrl.text =
              '${picked.year}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
        }
      },
    );
  }

  // ===========================================================
  // ADD CANDIDATE DIALOG
  // ===========================================================

  Future<void> _showAddCandidateDialog() async {
    // Load branches and exam types for dropdowns
    List<Map<String, dynamic>> branchesList = [];
    List<Map<String, dynamic>> examTypesList = [];
    try {
      final br = await api.branches();
      branchesList = (br.data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      final et = await api.examTypes();
      examTypesList = (et.data['data'] as List? ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    } catch (_) {}

    int? selectedBranchId = branchesList.isNotEmpty
        ? branchesList.first['id']
        : null;
    int? selectedExamTypeId = examTypesList.isNotEmpty
        ? examTypesList.first['id']
        : null;

    // Candidate status can also be selected while adding the candidate.
    String selectedStatus = 'Registered';

    final nameCtrl = TextEditingController();
    final emailCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final regNumCtrl = TextEditingController();
    final dateCtrl = TextEditingController();

    if (!mounted) return;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) {
          return Container(
            decoration: const BoxDecoration(
              color: AppColors.surfaceAlt,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            padding: EdgeInsets.fromLTRB(
              24,
              16,
              24,
              MediaQuery.of(ctx).viewInsets.bottom + 24,
            ),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Drag handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Title
                  Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF9A22C7), Color(0xFF6C1FB0)],
                          ),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          Icons.person_add_rounded,
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        'Add Candidate',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Name
                  _FieldLabel('Full Name *'),
                  const SizedBox(height: 6),
                  _StyledTextField(
                    controller: nameCtrl,
                    hint: 'Enter candidate name',
                    icon: Icons.person_outline_rounded,
                  ),

                  const SizedBox(height: 14),

                  // Register Number
                  _FieldLabel('Register Number'),
                  const SizedBox(height: 6),
                  _StyledTextField(
                    controller: regNumCtrl,
                    hint: 'Enter register number',
                    icon: Icons.badge_outlined,
                  ),

                  const SizedBox(height: 14),

                  // Branch dropdown
                  _FieldLabel('Branch'),
                  const SizedBox(height: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF9FAFB),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFE5E7EB)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<int>(
                        isExpanded: true,
                        value: selectedBranchId,
                        hint: const Text('Select branch'),
                        items: branchesList.map((b) {
                          return DropdownMenuItem<int>(
                            value: b['id'],
                            child: Text(
                              '${b['branch_name'] ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setSheetState(() {
                            selectedBranchId = val;
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Exam Type dropdown
                  _FieldLabel('Exam Type'),
                  const SizedBox(height: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF9FAFB),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFE5E7EB)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<int>(
                        isExpanded: true,
                        value: selectedExamTypeId,
                        hint: const Text('Select exam type'),
                        items: examTypesList.map((e) {
                          return DropdownMenuItem<int>(
                            value: e['id'],
                            child: Text(
                              '${e['name'] ?? ''}',
                              overflow: TextOverflow.ellipsis,
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          setSheetState(() {
                            selectedExamTypeId = val;
                          });
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Candidate Status
                  _FieldLabel('Status'),
                  const SizedBox(height: 6),
                  Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFFF9FAFB),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(0xFFE5E7EB)),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: selectedStatus,
                        hint: const Text('Select status'),
                        items: const [
                          DropdownMenuItem<String>(
                            value: 'Registered',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.how_to_reg_rounded,
                                  size: 18,
                                  color: Color(0xFF2563EB),
                                ),
                                SizedBox(width: 8),
                                Expanded(child: Text('Registered')),
                              ],
                            ),
                          ),
                          DropdownMenuItem<String>(
                            value: 'Absent',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.person_off_rounded,
                                  size: 18,
                                  color: Color(0xFFEA580C),
                                ),
                                SizedBox(width: 8),
                                Expanded(child: Text('Absent')),
                              ],
                            ),
                          ),
                          DropdownMenuItem<String>(
                            value: 'Rescheduled',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.event_repeat_rounded,
                                  size: 18,
                                  color: Color(0xFF9A22C7),
                                ),
                                SizedBox(width: 8),
                                Expanded(child: Text('Rescheduled')),
                              ],
                            ),
                          ),
                        ],
                        onChanged: (val) {
                          if (val != null) {
                            setSheetState(() => selectedStatus = val);
                          }
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Exam Date
                  _FieldLabel('Exam Date'),
                  const SizedBox(height: 6),
                  TextField(
                    controller: dateCtrl,
                    readOnly: true,
                    decoration: InputDecoration(
                      hintText: 'Select date',
                      suffixIcon: const Icon(Icons.calendar_today_rounded),
                      filled: true,
                      fillColor: const Color(0xFFF9FAFB),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
                      ),
                    ),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: DateTime.now(),
                        // Candidate dates are intentionally unrestricted:
                        // past, today, and future dates are all allowed.
                        firstDate: DateTime(1900),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) {
                        dateCtrl.text =
                            '${picked.year}-'
                            '${picked.month.toString().padLeft(2, '0')}-'
                            '${picked.day.toString().padLeft(2, '0')}';
                      }
                    },
                  ),

                  const SizedBox(height: 24),

                  // Save button
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF9A22C7),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      onPressed: () async {
                        if (nameCtrl.text.trim().isEmpty) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            const SnackBar(
                              content: Text('Candidate name is required'),
                            ),
                          );
                          return;
                        }
                        try {
                          await api.createCandidate({
                            'name': nameCtrl.text.trim(),
                            'email': emailCtrl.text.trim(),
                            'phone': phoneCtrl.text.trim(),
                            'register_number': regNumCtrl.text.trim(),
                            'branch_id': selectedBranchId,
                            'exam_type_id': selectedExamTypeId,
                            'status': selectedStatus,
                            'exam_date': dateCtrl.text,
                          });
                          if (ctx.mounted) {
                            Navigator.pop(ctx);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Candidate added!'),
                                backgroundColor: AppColors.green,
                              ),
                            );
                            reload();
                          }
                        } catch (e) {
                          if (ctx.mounted) {
                            ScaffoldMessenger.of(ctx).showSnackBar(
                              SnackBar(content: Text('Error: $e')),
                            );
                          }
                        }
                      },
                      child: const Text(
                        'Add Candidate',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // MODAL: ALL BRANCHES
  // ─────────────────────────────────────────────────────────────────────────
  void _showBranchesModal() async {
    try {
      final res = await api.branches();
      final list = (res.data['data'] as List? ?? [])
          .map((e) => Branch.fromMap(e))
          .toList();
      if (!mounted) return;
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (ctx) => Container(
          height: MediaQuery.of(ctx).size.height * 0.75,
          decoration: const BoxDecoration(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            children: [
              _ModalHandle(),
              _ModalHeader(
                icon: Icons.business_rounded,
                iconColor: Color(0xFF6C1FB0),
                iconBg: const Color(0xFFF0E3FA),
                title: 'All Branches',
                subtitle: '${list.length} branches registered',
              ),
              const Divider(height: 1),
              Expanded(
                child: list.isEmpty
                    ? const Center(child: Text('No branches available'))
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: list.length,
                        itemBuilder: (c, i) {
                          final b = list[i];
                          return Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFFE5E7EB),
                              ),
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 22,
                                  backgroundColor: const Color(0xFFF0E3FA),
                                  child: Text(
                                    b.name.isNotEmpty
                                        ? b.name[0].toUpperCase()
                                        : '?',
                                    style: const TextStyle(
                                      color: Color(0xFF6C1FB0),
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        b.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      if (b.region.isNotEmpty)
                                        Text(
                                          b.region,
                                          style: TextStyle(
                                            color: Colors.grey[600],
                                            fontSize: 12,
                                          ),
                                        ),
                                      if (b.address.isNotEmpty)
                                        Text(
                                          b.address,
                                          style: TextStyle(
                                            color: Colors.grey[500],
                                            fontSize: 11,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFDCFCE7),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    b.status,
                                    style: const TextStyle(
                                      color: AppColors.green,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error loading branches: $e')));
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // MODAL: FILTERED CANDIDATES (today / tomorrow / all)
  // ─────────────────────────────────────────────────────────────────────────
  void _showCandidatesModal(String title, String? filterDate) async {
    try {
      final res = await api.candidates();
      List<Candidate> list = (res.data['data'] as List? ?? [])
          .map((e) => Candidate.fromMap(e))
          .toList();
      if (filterDate != null && filterDate.isNotEmpty) {
        list = list.where((c) => c.date == filterDate).toList();
      }
      if (!mounted) return;

      final Color accentColor = filterDate == null
          ? AppColors.blue
          : filterDate.isNotEmpty
          ? AppColors.green
          : Color(0xFF6C1FB0);
      final Color accentBg = filterDate == null
          ? const Color(0xFFDBEAFE)
          : filterDate.isNotEmpty
          ? const Color(0xFFDCFCE7)
          : const Color(0xFFF0E3FA);

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (ctx) => Container(
          height: MediaQuery.of(ctx).size.height * 0.75,
          decoration: const BoxDecoration(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: Column(
            children: [
              _ModalHandle(),
              _ModalHeader(
                icon: Icons.people_alt_rounded,
                iconColor: accentColor,
                iconBg: accentBg,
                title: title,
                subtitle: list.isEmpty
                    ? 'No candidates'
                    : '${list.length} candidate${list.length == 1 ? '' : 's'}',
              ),
              const Divider(height: 1),
              Expanded(
                child: list.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.event_busy_rounded,
                              size: 56,
                              color: Colors.grey[300],
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'No candidates for $title',
                              style: TextStyle(
                                color: Colors.grey[500],
                                fontSize: 14,
                              ),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: list.length,
                        itemBuilder: (c, i) {
                          final item = list[i];
                          final statusColor =
                              item.status.toLowerCase().contains('pass')
                              ? AppColors.green
                              : item.status.toLowerCase().contains('fail')
                              ? const Color(0xFFE11D48)
                              : Color(0xFF6C1FB0);
                          final statusBg =
                              item.status.toLowerCase().contains('pass')
                              ? const Color(0xFFDCFCE7)
                              : item.status.toLowerCase().contains('fail')
                              ? const Color(0xFFFFE4E6)
                              : const Color(0xFFF0E3FA);
                          return Container(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: const Color(0xFFE5E7EB),
                              ),
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 22,
                                  backgroundColor: accentBg,
                                  child: Text(
                                    item.name.isNotEmpty
                                        ? item.name[0].toUpperCase()
                                        : '?',
                                    style: TextStyle(
                                      color: accentColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        item.name,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        '${item.examType} • ${item.branch}',
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 12,
                                        ),
                                      ),
                                      if (item.date.isNotEmpty)
                                        Text(
                                          '📅 ${item.date}',
                                          style: TextStyle(
                                            color: Colors.grey[500],
                                            fontSize: 11,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: statusBg,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        item.status.isEmpty
                                            ? 'Scheduled'
                                            : item.status,
                                        style: TextStyle(
                                          color: statusColor,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    if (item.registerNumber.isNotEmpty)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 4),
                                        child: Text(
                                          '#${item.registerNumber}',
                                          style: TextStyle(
                                            color: Colors.grey[400],
                                            fontSize: 10,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error loading candidates: $e')));
      }
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // MODAL: TODAY'S EXAMS (section heading tap)
  // ─────────────────────────────────────────────────────────────────────────
  void _showTodaysExamsModal(List<DashboardExam> exams) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        height: MediaQuery.of(ctx).size.height * 0.75,
        decoration: const BoxDecoration(
          color: AppColors.surfaceAlt,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            _ModalHandle(),
            _ModalHeader(
              icon: Icons.calendar_month_rounded,
              iconColor: Color(0xFF6C1FB0),
              iconBg: const Color(0xFFF0E3FA),
              title: "Today's Exams",
              subtitle: exams.isEmpty
                  ? 'No exams today'
                  : '${exams.length} exam session${exams.length == 1 ? '' : 's'}',
            ),
            const Divider(height: 1),
            Expanded(
              child: exams.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.event_busy_rounded,
                            size: 56,
                            color: Colors.grey[300],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            "No exams scheduled for today",
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: exams.length,
                      itemBuilder: (c, i) {
                        final e = exams[i];
                        Color statusColor;
                        Color statusBg;
                        IconData statusIcon;
                        switch (e.status.toLowerCase()) {
                          case 'completed':
                            statusColor = AppColors.green;
                            statusBg = const Color(0xFFDCFCE7);
                            statusIcon = Icons.check_circle_rounded;
                            break;
                          case 'in_progress':
                          case 'ongoing':
                            statusColor = const Color(0xFFD97706);
                            statusBg = const Color(0xFFFEF3C7);
                            statusIcon = Icons.play_circle_rounded;
                            break;
                          default:
                            statusColor = Color(0xFF6C1FB0);
                            statusBg = const Color(0xFFF0E3FA);
                            statusIcon = Icons.schedule_rounded;
                        }
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceAlt,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: const Color(0xFFE5E7EB)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.04),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF0E3FA),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Icon(
                                      Icons.school_rounded,
                                      color: Color(0xFF6C1FB0),
                                      size: 22,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          e.examTypeName,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 15,
                                          ),
                                        ),
                                        Text(
                                          e.branchName,
                                          style: TextStyle(
                                            color: Colors.grey[600],
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: statusBg,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(
                                          statusIcon,
                                          size: 12,
                                          color: statusColor,
                                        ),
                                        const SizedBox(width: 4),
                                        Text(
                                          e.status.isEmpty
                                              ? 'Scheduled'
                                              : e.status,
                                          style: TextStyle(
                                            color: statusColor,
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              const Divider(
                                height: 1,
                                color: Color(0xFFF3F4F6),
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  _InfoChip(
                                    icon: Icons.access_time_rounded,
                                    label: '${e.startTime} – ${e.endTime}',
                                  ),
                                  const SizedBox(width: 8),
                                  _InfoChip(
                                    icon: Icons.people_rounded,
                                    label:
                                        '${e.candidateCount} candidate${e.candidateCount == 1 ? '' : 's'}',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // MODAL: TOMORROW'S EXAM (section heading tap)
  // ─────────────────────────────────────────────────────────────────────────
  void _showTomorrowCandidatesModal(
    List<TomorrowBranchCandidates> tomorrow,
    DashboardStats stats,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        height: MediaQuery.of(ctx).size.height * 0.75,
        decoration: const BoxDecoration(
          color: AppColors.surfaceAlt,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          children: [
            _ModalHandle(),
            _ModalHeader(
              icon: Icons.groups_rounded,
              iconColor: const Color(0xFFE11D48),
              iconBg: const Color(0xFFFFE4E6),
              title: "Tomorrow's Exam",
              subtitle: prettyDate(stats.tomorrow),
            ),
            const Divider(height: 1),
            Expanded(
              child: tomorrow.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.event_busy_rounded,
                            size: 56,
                            color: Colors.grey[300],
                          ),
                          const SizedBox(height: 12),
                          Text(
                            "No candidates scheduled for tomorrow",
                            style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    )
                  : Column(
                      children: [
                        Expanded(
                          child: ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: tomorrow.length,
                            itemBuilder: (c, i) {
                              final item = tomorrow[i];
                              return Container(
                                margin: const EdgeInsets.only(bottom: 12),
                                decoration: BoxDecoration(
                                  color: AppColors.surfaceAlt,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: const Color(0xFFE5E7EB),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withValues(
                                        alpha: 0.04,
                                      ),
                                      blurRadius: 8,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        14,
                                        14,
                                        14,
                                        10,
                                      ),
                                      child: Row(
                                        children: [
                                          Container(
                                            width: 38,
                                            height: 38,
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFFE4E6),
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                            child: const Icon(
                                              Icons.location_on_rounded,
                                              color: Color(0xFFE11D48),
                                              size: 20,
                                            ),
                                          ),
                                          const SizedBox(width: 10),
                                          Expanded(
                                            child: Text(
                                              item.branchName,
                                              style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 15,
                                              ),
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 5,
                                            ),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFFFE4E6),
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                            ),
                                            child: Text(
                                              '${item.candidateCount} candidate${item.candidateCount == 1 ? '' : 's'}',
                                              style: const TextStyle(
                                                color: Color(0xFFE11D48),
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const Divider(
                                      height: 1,
                                      color: Color(0xFFF3F4F6),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                        14,
                                        10,
                                        14,
                                        14,
                                      ),
                                      child: Wrap(
                                        spacing: 8,
                                        runSpacing: 6,
                                        children: item.examBreakdown.entries.map(
                                          (entry) {
                                            return Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 10,
                                                    vertical: 5,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFF0E3FA),
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              child: Text(
                                                '${entry.key}: ${entry.value}',
                                                style: const TextStyle(
                                                  color: Color(0xFF6C1FB0),
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            );
                                          },
                                        ).toList(),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                        // Total footer
                        Container(
                          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF0E3FA),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                "Total Tomorrow's Exam",
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFF6C1FB0),
                                ),
                              ),
                              Text(
                                '${stats.tomorrowCandidates}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 20,
                                  color: Color(0xFF6C1FB0),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBranchSelector() {
    final branchContext = context.watch<BranchContext>();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.searchFill,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.searchBorder),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(.08),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<int?>(
          isExpanded: true,
          value: branchContext.selectedBranchId,
          icon: const Icon(Icons.keyboard_arrow_down_rounded),
          hint: const Text('Select Branch'),
          items: [
            ...branchContext.branches.map(
              (b) => DropdownMenuItem<int?>(
                value: b.id,
                child: Row(
                  children: [
                    const Icon(
                      Icons.business_rounded,
                      color: Color(0xFF6C1FB0),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        b.name,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          onChanged: (id) => branchContext.selectBranch(id),
        ),
      ),
    );
  }

  Widget _buildFixedBranchLabel() {
    final branchContext = context.watch<BranchContext>();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.searchFill,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.searchBorder),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withOpacity(.08),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          const Icon(Icons.business_rounded, color: Color(0xFF6C1FB0)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              branchContext.selectedBranchName,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  // ===========================================================
  // USER DASHBOARD: CANDIDATE ANALYSIS CHART
  // (Total / Rescheduled / Completed for the current month)
  // ===========================================================

  Widget _buildCandidateAnalysisChart({
    required int total,
    required int rescheduled,
    required int completed,
  }) {
    final maxValue = [
      total,
      rescheduled,
      completed,
    ].fold<int>(1, (m, v) => v > m ? v : m);

    Widget bar(String label, int value, Color color) {
      final fraction = (value / maxValue).clamp(0.0, 1.0);
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            SizedBox(
              width: 92,
              child: Text(
                label,
                style: const TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 12.5,
                ),
              ),
            ),
            Expanded(
              child: Stack(
                children: [
                  Container(
                    height: 18,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F1F6),
                      borderRadius: BorderRadius.circular(9),
                    ),
                  ),
                  FractionallySizedBox(
                    widthFactor: fraction,
                    child: Container(
                      height: 18,
                      decoration: BoxDecoration(
                        color: color,
                        borderRadius: BorderRadius.circular(9),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 32,
              child: Text(
                '$value',
                textAlign: TextAlign.right,
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceAlt,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEDE9FE)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x189A22C7),
            blurRadius: 16,
            offset: Offset(0, 7),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "This Month's Candidate Analysis",
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 15,
              color: Color(0xFF6C1FB0),
            ),
          ),
          const SizedBox(height: 12),
          bar('Total', total, const Color(0xFF4F46E5)),
          bar('Rescheduled', rescheduled, const Color(0xFF7C3AED)),
          bar('Completed', completed, AppColors.green),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,

      appBar: AppBar(
        elevation: 3,
        shadowColor: Colors.black26,
        toolbarHeight: AppBarStyle.height,
        shape: AppBarStyle.shape,
        backgroundColor: Color(0xFF9A22C7),
        foregroundColor: Colors.white,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF6C1FB0), Color(0xFF9A22C7), Color(0xFFE0189E)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Color(0x559A22C7),
                blurRadius: 24,
                offset: Offset(0, 8),
              ),
            ],
          ),
        ),

        title: Text(
          context.watch<AuthProvider>().role.trim().toLowerCase() == 'admin'
              ? 'Dashboard'
              : 'User Dashboard',
          style: AppBarStyle.titleStyle,
        ),

        actions: [
          IconButton(
            tooltip: 'Pending Payments',
            onPressed: _showPendingPaymentsSheet,
            icon: Stack(
              clipBehavior: Clip.none,
              children: [
                const Icon(Icons.notifications_rounded),
                if (_pendingCount > 0)
                  Positioned(
                    right: -2,
                    top: -2,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                      constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                      decoration: BoxDecoration(
                        color: AppColors.red,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF9A22C7), width: 1.4),
                      ),
                      child: Text(
                        _pendingCount > 99 ? '99+' : '$_pendingCount',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'Profile',
            onPressed: () {
              Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const ProfileScreen()));
            },
            icon: const Icon(Icons.person_rounded),
          ),
          IconButton(
            tooltip: 'Refresh',
            onPressed: reload,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),

      body: FutureBuilder<Map<String, dynamic>>(
        future: future,

        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const LoadingView();
          }

          if (snapshot.hasError) {
            return ErrorView(message: '${snapshot.error}', onRetry: reload);
          }

          final data = snapshot.requireData;

          final stats = data['stats'] as DashboardStats;
          final isAdmin =
              context.read<AuthProvider>().role.trim().toLowerCase() == 'admin';

          final currentMonthTotal = data['currentMonthTotal'] as int? ?? 0;
          final currentMonthRescheduled =
              data['currentMonthRescheduled'] as int? ?? 0;
          final currentMonthCompleted =
              data['currentMonthCompleted'] as int? ?? 0;
          final currentMonthExpense =
              (data['currentMonthExpense'] as num?)?.toDouble() ?? 0.0;
          final previousMonthExpense =
              (data['previousMonthExpense'] as num?)?.toDouble() ?? 0.0;
          final voucherStats = Map<String, dynamic>.from(
            data['voucherStats'] ?? {},
          );
          final totalProfit =
              double.tryParse('${voucherStats['realized_profit'] ?? 0}') ?? 0.0;
          final salesRevenue =
              double.tryParse('${voucherStats['sales_revenue'] ?? 0}') ?? 0.0;
          final availableVouchers =
              int.tryParse('${voucherStats['available'] ?? 0}') ?? 0;

          /*
           * IMPORTANT:
           *
           * Branch priority:
           *
           * 1. Branches having today's exams first
           * 2. Among those branches, more candidates first
           * 3. Branches having no exams come last
           * 4. No-exam branches are sorted alphabetically
           */
          final branches =
              List<DashboardBranch>.from(
                    data['branches'] as List<DashboardBranch>,
                  )
                  .where(
                    (b) =>
                        b.todayCandidates > 0 ||
                        b.tomorrowCandidates > 0 ||
                        b.todayExams > 0,
                  )
                  .toList();

          branches.sort((a, b) {
            final aHasExam = a.todayExams > 0;

            final bHasExam = b.todayExams > 0;

            // -----------------------------------------
            // 1. Exam branches first
            // -----------------------------------------

            if (aHasExam && !bHasExam) {
              return -1;
            }

            if (!aHasExam && bHasExam) {
              return 1;
            }

            // -----------------------------------------
            // 2. If both have exams,
            //    more candidates first
            // -----------------------------------------

            if (aHasExam && bHasExam) {
              final candidateCompare = b.todayCandidates.compareTo(
                a.todayCandidates,
              );

              if (candidateCompare != 0) {
                return candidateCompare;
              }

              // If same candidate count,
              // more exams first.
              final examCompare = b.todayExams.compareTo(a.todayExams);

              if (examCompare != 0) {
                return examCompare;
              }
            }

            // -----------------------------------------
            // 3. No-exam branches at bottom
            // 4. Alphabetical order
            // -----------------------------------------

            return a.name.toLowerCase().compareTo(b.name.toLowerCase());
          });

          final todayCandidates =
              data['todayCandidates'] as List<Candidate>? ?? [];

          final tomorrowCandidates =
              data['tomorrowCandidates'] as List<Candidate>? ?? [];

          return Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color(0xFFF5F0FF),
                  Color(0xFFFFF8FC),
                  Color(0xFFF1F5FF),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: RefreshIndicator(
              color: Color(0xFF6C1FB0),

              onRefresh: () async {
                reload();
              },

              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),

                padding: const EdgeInsets.fromLTRB(16, 18, 16, 24),

                children: [
                  // =================================================
                  // GLOBAL BRANCH SELECTOR (Admin) /
                  // FIXED BRANCH LABEL (User)
                  // =================================================
                  isAdmin ? _buildBranchSelector() : _buildFixedBranchLabel(),

                  const SizedBox(height: 16),

                  // =================================================
                  // KPI CARDS
                  // =================================================
                  Container(
                    padding: EdgeInsets.zero,
                    decoration: const BoxDecoration(color: Colors.transparent),
                    child: GridView.count(
                      crossAxisCount: 2,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.45,
                      children: [
                        // ---------------------------------------------
                        // TOTAL EXAMS - FIRST
                        // ---------------------------------------------
                        _KpiCard(
                          title: 'Total Exams',
                          value: '${stats.totalExams}',
                          icon: Icons.menu_book_rounded,
                          tint: const Color(0xFFE0E7FF),
                          iconColor: const Color(0xFF4F46E5),
                        ),

                        // ---------------------------------------------
                        // TODAY'S EXAM
                        // ---------------------------------------------
                        _KpiCard(
                          title: "Today's Exam",
                          value: '${stats.todayCandidates}',
                          icon: Icons.groups_rounded,
                          tint: const Color(0xFFDCFCE7),
                          iconColor: AppColors.green,
                        ),

                        // ---------------------------------------------
                        // NEXT DAY EXAM
                        // ---------------------------------------------
                        _KpiCard(
                          title: 'Next Day Exam',
                          value: '${stats.tomorrowCandidates}',
                          icon: Icons.event_available_rounded,
                          tint: const Color(0xFFFFE4E6),
                          iconColor: const Color(0xFFE11D48),
                        ),

                        // ---------------------------------------------
                        // TOTAL CANDIDATES
                        // ---------------------------------------------
                        _KpiCard(
                          title: 'Total Candidates',
                          value: '$currentMonthTotal',
                          icon: Icons.verified_rounded,
                          tint: const Color(0xFFDBEAFE),
                          iconColor: AppColors.blue,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    const AttendedCandidatesScreen(),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // =================================================
                  // CANDIDATE ANALYSIS CHART (USER DASHBOARD ONLY)
                  // =================================================
                  if (!isAdmin) ...[
                    _buildCandidateAnalysisChart(
                      total: currentMonthTotal,
                      rescheduled: currentMonthRescheduled,
                      completed: currentMonthCompleted,
                    ),
                    const SizedBox(height: 20),
                  ],

                  // =================================================
                  // FINANCE & VOUCHER KPI CARDS (ADMIN ONLY)
                  // =================================================
                  if (isAdmin) ...[
                    Container(
                      padding: EdgeInsets.zero,
                      decoration: const BoxDecoration(
                        color: Colors.transparent,
                      ),
                      child: GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                        childAspectRatio: 1.45,
                        children: [
                          _KpiCard(
                            title: 'Total Profit',
                            value: '₹${totalProfit.toStringAsFixed(2)}',
                            icon: Icons.trending_up_rounded,
                            tint: const Color(0xFFDCFCE7),
                            iconColor: AppColors.green,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const VouchersScreen(initialTab: 1),
                                ),
                              );
                            },
                          ),
                          _KpiCard(
                            title: 'Available Voucher',
                            value: '$availableVouchers',
                            icon: Icons.confirmation_num_rounded,
                            tint: const Color(0xFFF0E3FA),
                            iconColor: const Color(0xFF6C1FB0),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const AvailableVouchersScreen(),
                                ),
                              );
                            },
                          ),
                          _KpiCard(
                            title: 'Total Expenses',
                            value: '₹${currentMonthExpense.toStringAsFixed(2)}',
                            icon: Icons.account_balance_wallet_rounded,
                            tint: const Color(0xFFF0E3FA),
                            iconColor: const Color(0xFF6C1FB0),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const ExpensesScreen(),
                                ),
                              );
                            },
                          ),
                          _KpiCard(
                            title: 'Sales',
                            value: '₹${salesRevenue.toStringAsFixed(2)}',
                            icon: Icons.payments_rounded,
                            tint: const Color(0xFFD1FAE5),
                            iconColor: const Color(0xFF059669),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const VouchersScreen(initialTab: 1),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // =================================================
                    // DASHBOARD GRAPHICAL REPRESENTATION
                    // =================================================
                    _DashboardMetricsChart(
                      currentExpense: currentMonthExpense,
                      previousExpense: previousMonthExpense,
                      profit: totalProfit,
                      sales: salesRevenue,
                      onExpensesTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const ExpensesScreen(),
                          ),
                        );
                      },
                      onProfitTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const VouchersScreen(initialTab: 1),
                          ),
                        );
                      },
                      onSalesTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const VouchersScreen(initialTab: 1),
                          ),
                        );
                      },
                    ),

                    const SizedBox(height: 20),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ================================================================
// FIELD LABEL (for dialogs)
// ================================================================

// ignore: non_constant_identifier_names
Widget _FieldLabel(String text) {
  return Text(
    text,
    style: const TextStyle(
      fontWeight: FontWeight.w700,
      fontSize: 13,
      color: Color(0xFF4B5563),
    ),
  );
}

// ================================================================
// STYLED TEXT FIELD (for dialogs)
// ================================================================

class _StyledTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData? icon;
  final TextInputType? keyboardType;

  const _StyledTextField({
    required this.controller,
    required this.hint,
    this.icon,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        hintText: hint,
        prefixIcon: icon != null ? Icon(icon, size: 20) : null,
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFE5E7EB)),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 14,
          vertical: 14,
        ),
      ),
    );
  }
}

// ================================================================
// QUICK ACTION CARD
// ================================================================

class _QuickActionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Color> gradientColors;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.title,
    required this.icon,
    required this.gradientColors,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: gradientColors,
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: gradientColors.first.withOpacity(.28),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.20),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: Colors.white, size: 23),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  height: 1.25,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ================================================================
// KPI CARD
// ================================================================

class _DashboardMetricsChart extends StatelessWidget {
  final double currentExpense;
  final double previousExpense;
  final double profit;
  final double sales;
  final VoidCallback? onExpensesTap;
  final VoidCallback? onProfitTap;
  final VoidCallback? onSalesTap;

  const _DashboardMetricsChart({
    required this.currentExpense,
    required this.previousExpense,
    required this.profit,
    required this.sales,
    this.onExpensesTap,
    this.onProfitTap,
    this.onSalesTap,
  });

  static const double _barAreaHeight = 110;
  static const double _maxBarHeight = 64;

  String _money(double value) {
    // Compact Indian-style formatting so a big figure never forces a
    // smaller one's label to overflow or shrink to nothing.
    if (value >= 10000000) return '₹${(value / 10000000).toStringAsFixed(2)}Cr';
    if (value >= 100000) return '₹${(value / 100000).toStringAsFixed(2)}L';
    if (value >= 1000) return '₹${(value / 1000).toStringAsFixed(1)}K';
    return '₹${value.toStringAsFixed(0)}';
  }

  Widget _miniBar({
    required double value,
    required double maxValue,
    required Color color,
    required String label,
  }) {
    final ratio = (value / maxValue).clamp(0.0, 1.0);
    // Always keep a visible sliver so a ₹0 month still reads as "zero".
    final barHeight = 6 + (ratio * (_maxBarHeight - 6));
    return Expanded(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              _money(value),
              maxLines: 1,
              style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.w900,
                color: color,
              ),
            ),
          ),
          const SizedBox(height: 6),
          AnimatedContainer(
            duration: const Duration(milliseconds: 350),
            curve: Curves.easeOutCubic,
            height: barHeight,
            width: double.infinity,
            constraints: const BoxConstraints(maxWidth: 32),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(.55)],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 9.5,
              fontWeight: FontWeight.w700,
              color: Color(0xFF6B7280),
            ),
          ),
        ],
      ),
    );
  }

  Widget _singleBar({
    required double value,
    required Color color,
    required IconData icon,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            _money(value),
            maxLines: 1,
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 6),
        Container(
          height: _maxBarHeight,
          width: double.infinity,
          constraints: const BoxConstraints(maxWidth: 52),
          alignment: Alignment.bottomCenter,
          padding: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [color, color.withOpacity(.55)],
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: Colors.white, size: 16),
        ),
      ],
    );
  }

  Widget _groupBox({
    required String title,
    required Color accent,
    required Widget child,
    VoidCallback? onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 10, 8, 10),
        decoration: BoxDecoration(
          color: const Color(0xFFFAFAFA),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accent.withOpacity(.25)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 11.5,
                fontWeight: FontWeight.w900,
                color: accent,
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(height: _barAreaHeight, child: child),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final expenseMax = currentExpense > previousExpense
        ? currentExpense
        : previousExpense;
    final safeExpenseMax = expenseMax <= 0 ? 1.0 : expenseMax;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 18),
      decoration: BoxDecoration(
        color: AppColors.surfaceAlt,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFEDE9FE)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 14,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Dashboard Overview',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w900,
              color: Color(0xFF1F2937),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Expenses vs last month, plus profit and sales — tap a box for details',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Color(0xFF6B7280),
            ),
          ),
          const SizedBox(height: 16),
          IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ---------------------------------------------------
                // EXPENSES — previous month vs this month, grouped
                // ---------------------------------------------------
                Expanded(
                  flex: 5,
                  child: _groupBox(
                    title: 'Expenses',
                    accent: const Color(0xFF6C1FB0),
                    onTap: onExpensesTap,
                    child: Row(
                      children: [
                        _miniBar(
                          value: previousExpense,
                          maxValue: safeExpenseMax,
                          color: const Color(0xFFC9A6F0),
                          label: 'Last mo.',
                        ),
                        const SizedBox(width: 8),
                        _miniBar(
                          value: currentExpense,
                          maxValue: safeExpenseMax,
                          color: const Color(0xFF6C1FB0),
                          label: 'This mo.',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // ---------------------------------------------------
                // PROFIT — single current total
                // ---------------------------------------------------
                Expanded(
                  flex: 3,
                  child: _groupBox(
                    title: 'Profit',
                    accent: const Color(0xFF16A34A),
                    onTap: onProfitTap,
                    child: Center(
                      child: _singleBar(
                        value: profit,
                        color: const Color(0xFF16A34A),
                        icon: Icons.trending_up_rounded,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // ---------------------------------------------------
                // SALES — single current total
                // ---------------------------------------------------
                Expanded(
                  flex: 3,
                  child: _groupBox(
                    title: 'Sales',
                    accent: const Color(0xFF059669),
                    onTap: onSalesTap,
                    child: Center(
                      child: _singleBar(
                        value: sales,
                        color: const Color(0xFF059669),
                        icon: Icons.payments_rounded,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color tint;
  final Color iconColor;
  final VoidCallback? onTap;

  const _KpiCard({
    required this.title,
    required this.value,
    required this.icon,
    required this.tint,
    required this.iconColor,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.fromLTRB(11, 9, 10, 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [tint.withOpacity(.38), Colors.white.withOpacity(.94)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: iconColor.withOpacity(.14), width: 1),
            boxShadow: [
              BoxShadow(
                color: iconColor.withOpacity(.09),
                blurRadius: 18,
                offset: const Offset(0, 7),
              ),
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -28,
                bottom: -38,
                child: Container(
                  width: 110,
                  height: 110,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: iconColor.withOpacity(.035),
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                          color: iconColor.withOpacity(.11),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(icon, color: iconColor, size: 18),
                      ),
                      const Spacer(),
                      if (onTap != null)
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 11,
                          color: iconColor.withOpacity(.45),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textMuted,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textDark,
                      letterSpacing: -.35,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: iconColor.withOpacity(.08),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.remove_rounded,
                              size: 10,
                              color: iconColor,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              '0%',
                              style: TextStyle(
                                fontSize: 9,
                                fontWeight: FontWeight.w800,
                                color: iconColor,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      SizedBox(
                        width: 52,
                        height: 21,
                        child: CustomPaint(
                          painter: _KpiSparklinePainter(color: iconColor),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _KpiSparklinePainter extends CustomPainter {
  final Color color;

  const _KpiSparklinePainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final points = <Offset>[
      Offset(0, size.height * .78),
      Offset(size.width * .15, size.height * .62),
      Offset(size.width * .30, size.height * .70),
      Offset(size.width * .44, size.height * .42),
      Offset(size.width * .58, size.height * .57),
      Offset(size.width * .73, size.height * .30),
      Offset(size.width * .86, size.height * .38),
      Offset(size.width, size.height * .12),
    ];

    final linePaint = Paint()
      ..color = color
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fillPaint = Paint()
      ..color = color.withOpacity(.055)
      ..style = PaintingStyle.fill;

    final linePath = Path()..moveTo(points.first.dx, points.first.dy);
    final fillPath = Path()
      ..moveTo(points.first.dx, size.height)
      ..lineTo(points.first.dx, points.first.dy);

    for (int i = 1; i < points.length; i++) {
      linePath.lineTo(points[i].dx, points[i].dy);
      fillPath.lineTo(points[i].dx, points[i].dy);
    }

    fillPath
      ..lineTo(points.last.dx, size.height)
      ..close();

    canvas
      ..drawPath(fillPath, fillPaint)
      ..drawPath(linePath, linePaint);

    canvas.drawCircle(points.last, 2.8, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _KpiSparklinePainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

// ================================================================
// SECTION CARD
// ================================================================

class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String? action;
  final Widget? trailing;
  final Widget child;
  final VoidCallback? onTap;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.child,
    this.action,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final header = InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFFF0E3FA),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: Color(0xFF6C1FB0), size: 21),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: Color(0xFF111827),
              ),
            ),
          ),
          if (trailing != null) trailing!,
          if (action != null || onTap != null)
            Icon(
              Icons.chevron_right_rounded,
              color: onTap != null ? Color(0xFF6C1FB0) : Colors.grey[400],
            ),
        ],
      ),
    );

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      decoration: BoxDecoration(
        color: AppColors.surfaceAlt,
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0D000000),
            blurRadius: 14,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(children: [header, const SizedBox(height: 10), child]),
    );
  }
}

void _showDashboardBranchDetails(BuildContext context, DashboardBranch b) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Container(
      decoration: const BoxDecoration(
        color: AppColors.surfaceAlt,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: EdgeInsets.fromLTRB(
        24,
        16,
        24,
        MediaQuery.of(ctx).padding.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: const Color(0xFFF0E3FA),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: Text(
                    b.name.isNotEmpty ? b.name[0].toUpperCase() : '?',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF6C1FB0),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      b.name,
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: b.status.toLowerCase() == 'active'
                            ? const Color(0xFFDCFCE7)
                            : const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        b.status,
                        style: TextStyle(
                          color: b.status.toLowerCase() == 'active'
                              ? AppColors.green
                              : const Color(0xFF6B7280),
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Text(
            'TODAY\'S ACTIVITY',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: Colors.grey,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 14),
          _detailRow(
            Icons.event_available_rounded,
            'Today\'s Exams',
            '${b.todayExams} sessions scheduled',
          ),
          const SizedBox(height: 12),
          _detailRow(
            Icons.groups_rounded,
            'Today\'s Candidates',
            '${b.todayCandidates} candidates attending',
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: OutlinedButton.icon(
              onPressed: () => Navigator.pop(ctx),
              icon: const Icon(Icons.close_rounded),
              label: const Text('Close'),
              style: OutlinedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

Widget _detailRow(IconData icon, String label, String value) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, size: 18, color: Color(0xFF6C1FB0)),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                color: Colors.grey,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: Color(0xFF1F2937),
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

// ================================================================
// BRANCH ROW
// ================================================================

class _BranchRow extends StatelessWidget {
  final DashboardBranch branch;

  const _BranchRow({required this.branch});

  @override
  Widget build(BuildContext context) {
    final hasExams =
        branch.todayCandidates > 0 ||
        branch.tomorrowCandidates > 0 ||
        branch.todayExams > 0;

    return InkWell(
      onTap: () => _showDashboardBranchDetails(context, branch),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),

        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),

        decoration: BoxDecoration(
          color: hasExams ? const Color(0xFFFAF8FF) : const Color(0xFFF9FAFB),

          borderRadius: BorderRadius.circular(16),
        ),

        child: Row(
          children: [
            // ---------------------------------------------
            // BRANCH ICON
            // ---------------------------------------------
            Container(
              width: 42,
              height: 42,

              decoration: BoxDecoration(
                color: hasExams
                    ? const Color(0xFFEDE9FE)
                    : const Color(0xFFF3F4F6),

                borderRadius: BorderRadius.circular(13),
              ),

              child: Icon(
                Icons.business_rounded,

                color: hasExams ? Color(0xFF6C1FB0) : const Color(0xFF9CA3AF),
              ),
            ),

            const SizedBox(width: 10),

            // ---------------------------------------------
            // BRANCH DETAILS
            // ---------------------------------------------
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,

                children: [
                  Text(
                    branch.name,

                    maxLines: 1,

                    overflow: TextOverflow.ellipsis,

                    style: const TextStyle(
                      fontWeight: FontWeight.w800,

                      fontSize: 14.5,
                    ),
                  ),

                  const SizedBox(height: 3),

                  Text(
                    branch.todayCandidates > 0 && branch.tomorrowCandidates > 0
                        ? '${branch.todayCandidates} candidates today • ${branch.tomorrowCandidates} tomorrow'
                        : branch.todayCandidates > 0
                        ? '${branch.todayCandidates} ${branch.todayCandidates == 1 ? "candidate" : "candidates"} today'
                        : branch.tomorrowCandidates > 0
                        ? '${branch.tomorrowCandidates} ${branch.tomorrowCandidates == 1 ? "candidate" : "candidates"} tomorrow'
                        : '${branch.todayExams} exams scheduled',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 6),

            // ---------------------------------------------
            // STATUS
            // ---------------------------------------------
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFDCFCE7),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                branch.totalScheduled > 0
                    ? '${branch.totalScheduled} Candidate${branch.totalScheduled > 1 ? "s" : ""}'
                    : 'Active',
                style: const TextStyle(
                  color: AppColors.green,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ================================================================
// TODAY'S EXAM ROW
// ================================================================

class _ExamRow extends StatelessWidget {
  final DashboardExam exam;

  const _ExamRow({required this.exam});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),

      padding: const EdgeInsets.all(11),

      decoration: BoxDecoration(
        color: const Color(0xFFFAF8FF),

        borderRadius: BorderRadius.circular(16),
      ),

      child: Row(
        children: [
          Container(
            width: 5,
            height: 56,

            decoration: BoxDecoration(
              color: Color(0xFF6C1FB0),

              borderRadius: BorderRadius.circular(8),
            ),
          ),

          const SizedBox(width: 10),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              children: [
                Text(
                  exam.examTypeName,

                  style: const TextStyle(
                    fontWeight: FontWeight.w900,

                    fontSize: 15,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  exam.branchName,

                  style: const TextStyle(
                    color: Color(0xFF4B5563),

                    fontSize: 12,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  '${exam.startTime} • '
                  '${exam.candidateCount} candidates',

                  style: const TextStyle(
                    color: Color(0xFF6B7280),

                    fontSize: 11.5,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),

            decoration: BoxDecoration(
              color: const Color(0xFFDCFCE7),

              borderRadius: BorderRadius.circular(20),
            ),

            child: const Text(
              'Scheduled',

              style: TextStyle(
                color: AppColors.green,

                fontSize: 10.5,

                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// TOMORROW'S EXAM ROW
// ================================================================

class _TomorrowRow extends StatelessWidget {
  final TomorrowBranchCandidates item;

  const _TomorrowRow({required this.item});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,

      contentPadding: const EdgeInsets.symmetric(horizontal: 2),

      leading: const CircleAvatar(
        backgroundColor: Color(0xFFF0E3FA),

        child: Icon(
          Icons.location_on_rounded,

          color: Color(0xFF6C1FB0),

          size: 19,
        ),
      ),

      title: Text(
        item.branchName,

        style: const TextStyle(fontWeight: FontWeight.w800),
      ),

      subtitle: Text(
        item.examBreakdown.entries
            .map((entry) => '${entry.key}: ${entry.value}')
            .join(' • '),

        style: const TextStyle(fontSize: 11.5),
      ),

      trailing: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),

        decoration: BoxDecoration(
          color: const Color(0xFFF0E3FA),

          borderRadius: BorderRadius.circular(20),
        ),

        child: Text(
          '${item.candidateCount}',

          style: const TextStyle(
            color: Color(0xFF6C1FB0),

            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }
}

// ================================================================
// CANDIDATE ROW (FOR DASHBOARD SECTIONS)
// ================================================================

class _CandidateRow extends StatelessWidget {
  final Candidate candidate;

  const _CandidateRow({required this.candidate});

  // Color generator based on name
  Color _avatarBg(String name) {
    final colors = [
      const Color(0xFFF0E3FA),
      const Color(0xFFDCFCE7),
      const Color(0xFFDBEAFE),
      const Color(0xFFFFE4E6),
      const Color(0xFFFEF3C7),
      const Color(0xFFEDE9FE),
    ];
    if (name.isEmpty) return colors[0];
    final hash = name.codeUnits.fold(0, (prev, elem) => prev + elem);
    return colors[hash % colors.length];
  }

  Color _avatarText(String name) {
    final colors = [
      Color(0xFF6C1FB0),
      AppColors.green,
      AppColors.blue,
      const Color(0xFFE11D48),
      const Color(0xFFD97706),
      const Color(0xFF9333EA),
    ];
    if (name.isEmpty) return colors[0];
    final hash = name.codeUnits.fold(0, (prev, elem) => prev + elem);
    return colors[hash % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    final initial = candidate.name.isNotEmpty
        ? candidate.name[0].toUpperCase()
        : '?';

    // Status colors
    Color statusColor;
    Color statusBg;
    final s = candidate.status.toLowerCase();
    if (s.contains('pass') || s == 'completed') {
      statusColor = const Color(0xFF9A22C7);
      statusBg = const Color(0xFFDCFCE7);
    } else if (s.contains('fail') || s == 'cancelled') {
      statusColor = const Color(0xFFE11D48);
      statusBg = const Color(0xFFFFE4E6);
    } else if (s == 'in progress' || s == 'in_progress' || s == 'ongoing') {
      statusColor = const Color(0xFFD97706);
      statusBg = const Color(0xFFFEF3C7);
    } else if (s == 'scheduled') {
      statusColor = const Color(0xFF9A22C7);
      statusBg = const Color(0xFFF0E3FA);
    } else if (s == 'no show' || s == 'no_show' || s == 'absent') {
      statusColor = const Color(0xFFEA580C);
      statusBg = const Color(0xFFFFEDD5);
    } else {
      statusColor = const Color(0xFF2563EB);
      statusBg = const Color(0xFFDBEAFE);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: _avatarBg(candidate.name),
            child: Text(
              initial,
              style: TextStyle(
                color: _avatarText(candidate.name),
                fontWeight: FontWeight.w900,
                fontSize: 15,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  candidate.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14.5,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${candidate.registerNumber.isNotEmpty ? '#${candidate.registerNumber}' : 'ID: ${candidate.id}'} • ${candidate.examType} (${candidate.branch})',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF6B7280),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: statusBg,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              candidate.status.isEmpty ? 'Registered' : candidate.status,
              style: TextStyle(
                color: statusColor,
                fontSize: 10.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// EMPTY TEXT
// ================================================================

class _EmptyText extends StatelessWidget {
  final String text;

  const _EmptyText(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 22),

      child: Center(
        child: Text(
          text,

          textAlign: TextAlign.center,

          style: const TextStyle(
            color: Color(0xFF6B7280),

            fontSize: 13,

            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

// ================================================================
// MODAL HANDLE (drag indicator)
// ================================================================

class _ModalHandle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 4),
      child: Center(
        child: Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }
}

// ================================================================
// MODAL HEADER
// ================================================================

class _ModalHeader extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;

  const _ModalHeader({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: iconColor, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 13, color: Colors.grey[500]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ================================================================
// INFO CHIP (small label with icon)
// ================================================================

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: Colors.grey[600]),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[700],
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
